function xdot = xdotpneu(x,t)

xdot = jointdynamics4state(0.0,0.0,x)